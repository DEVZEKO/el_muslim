

document.getElementById("p13").addEventListener("click", function () {
  var audio = document.getElementById('q13');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p17").addEventListener("click", function () {
  var audio = document.getElementById('q17');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p18").addEventListener("click", function () {
  var audio = document.getElementById('q18');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});


document.getElementById("p26").addEventListener("click", function () {
  var audio = document.getElementById('q26');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});



document.getElementById("p31").addEventListener("click", function () {
  var audio = document.getElementById('q31');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p32").addEventListener("click", function () {
  var audio = document.getElementById('q32');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});


document.getElementById("p41").addEventListener("click", function () {
  var audio = document.getElementById('q41');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p42").addEventListener("click", function () {
  var audio = document.getElementById('q42');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p44").addEventListener("click", function () {
  var audio = document.getElementById('q44');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p50").addEventListener("click", function () {
  var audio = document.getElementById('q50');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p53").addEventListener("click", function () {
  var audio = document.getElementById('q53');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p54").addEventListener("click", function () {
  var audio = document.getElementById('q54');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p55").addEventListener("click", function () {
  var audio = document.getElementById('q55');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p56").addEventListener("click", function () {
  var audio = document.getElementById('q56');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p59").addEventListener("click", function () {
  var audio = document.getElementById('q59');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p64").addEventListener("click", function () {
  var audio = document.getElementById('q64');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p66").addEventListener("click", function () {
  var audio = document.getElementById('q66');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p67").addEventListener("click", function () {
  var audio = document.getElementById('q67');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p68").addEventListener("click", function () {
  var audio = document.getElementById('q68');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p70").addEventListener("click", function () {
  var audio = document.getElementById('q70');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p72").addEventListener("click", function () {
  var audio = document.getElementById('q72');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p76").addEventListener("click", function () {
  var audio = document.getElementById('q76');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p79").addEventListener("click", function () {
  var audio = document.getElementById('q79');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p85").addEventListener("click", function () {
  var audio = document.getElementById('q85');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p88").addEventListener("click", function () {
  var audio = document.getElementById('q88');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});