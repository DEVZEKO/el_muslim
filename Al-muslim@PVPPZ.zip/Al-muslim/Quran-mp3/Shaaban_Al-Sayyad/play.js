document.getElementById("p3").addEventListener("click", function () {
  var audio = document.getElementById('q3');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p35").addEventListener("click", function () {
  var audio = document.getElementById('q35');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p87").addEventListener("click", function () {
  var audio = document.getElementById('q87');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p88").addEventListener("click", function () {
  var audio = document.getElementById('q88');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p89").addEventListener("click", function () {
  var audio = document.getElementById('q89');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p90").addEventListener("click", function () {
  var audio = document.getElementById('q90');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p91").addEventListener("click", function () {
  var audio = document.getElementById('q91');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p92").addEventListener("click", function () {
  var audio = document.getElementById('q92');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p94").addEventListener("click", function () {
  var audio = document.getElementById('q94');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p95").addEventListener("click", function () {
  var audio = document.getElementById('q95');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p96").addEventListener("click", function () {
  var audio = document.getElementById('q96');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p97").addEventListener("click", function () {
  var audio = document.getElementById('q97');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p98").addEventListener("click", function () {
  var audio = document.getElementById('q98');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p99").addEventListener("click", function () {
  var audio = document.getElementById('q99');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p100").addEventListener("click", function () {
  var audio = document.getElementById('q100');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p101").addEventListener("click", function () {
  var audio = document.getElementById('q101');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p102").addEventListener("click", function () {
  var audio = document.getElementById('q102');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p103").addEventListener("click", function () {
  var audio = document.getElementById('q103');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p104").addEventListener("click", function () {
  var audio = document.getElementById('q104');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});

document.getElementById("p105").addEventListener("click", function () {
  var audio = document.getElementById('q105');
  if (this.className == 'is-playing') {
    this.className = "";
    this.innerHTML = "<i class='fas fa-play'></i>"
    audio.pause();
  } else {
    this.className = "is-playing";
    this.innerHTML = "<i class='fas fa-pause'></i>";
    audio.play();
  }
});